// File: LostFoundTable.jsx
import React from 'react';
import { FiCheck, FiEye } from 'react-icons/fi';

const LostFoundTable = ({
  activeTab,
  filteredLostItems,
  filteredFoundItems,
  markAsFound,
  searchTerm,
  setSearchTerm,
  onViewDetails
}) => {
  const renderNoDataMessage = () => (
    <div className="no-data-message">
      <div className="sad-emoji">😞</div>
      <h3>No items found</h3>
      <p>We couldn't find any {activeTab === 'lost' ? 'lost' : 'found'} items matching your search.</p>
      {searchTerm && (
        <button className="clear-search" onClick={() => setSearchTerm('')}>
          Clear search
        </button>
      )}
    </div>
  );

  const renderRow = (item, isLost = false) => {
    const rowProps = !isLost ? { onClick: () => onViewDetails(item), className: 'clickable-row' } : {};
    return (
      <tr key={item.id} {...rowProps}>
        <td>{item.type === 'card' ? '💳 Card' : '🧳 Item'}</td>
        <td>{item.type === 'card' ? `${item.number}` : `${item.name} - ${item.description}`}</td>
        <td>{item.owner || 'Unknown'}</td>
        <td>{isLost ? item.placeLost : item.placeFound}</td>
        <td>{isLost ? item.reportedBy : item.foundBy}</td>
        <td>{isLost ? item.reporterPhone : item.finderPhone}</td>
        <td>{item.date}</td>
        <td><span className={`status-badge ${item.status}`}>{item.status}</span></td>
        <td>
          {isLost && item.status === 'pending' ? (
            <button
              className="found-button"
              onClick={(e) => {
                e.stopPropagation();
                markAsFound(item.id);
              }}
            >
              <FiCheck /> Found
            </button>
          ) : (
            <button
              className="view-button"
              onClick={(e) => {
                e.stopPropagation();
                onViewDetails(item);
              }}
            >
              <FiEye /> Details
            </button>
          )}
        </td>
      </tr>
    );
  };

  if (activeTab === 'lost') {
    if (!filteredLostItems.length) return renderNoDataMessage();
    return (
      <table className="items-table">
        <thead>
          <tr>
            <th>Type</th>
            <th>Details</th>
            <th>Owner</th>
            <th>Place Lost</th>
            <th>Reported By</th>
            <th>Phone</th>
            <th>Date & Time</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredLostItems.map(item => renderRow(item, true))}
        </tbody>
      </table>
    );
  } else {
    if (!filteredFoundItems.length) return renderNoDataMessage();
    return (
      <table className="items-table">
        <thead>
          <tr>
            <th>Type</th>
            <th>Details</th>
            <th>Owner</th>
            <th>Place Found</th>
            <th>Found By</th>
            <th>Phone</th>
            <th>Date & Time</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredFoundItems.map(item => renderRow(item))}
        </tbody>
      </table>
    );
  }
};

export default LostFoundTable;