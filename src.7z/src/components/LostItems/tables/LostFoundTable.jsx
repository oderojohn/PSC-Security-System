import React, { useState } from 'react';
import LostItemsTable from './LostItemsTable';
import FoundItemsTable from './FoundItemsTable';
import PickedItemsTable from '../PickedItemsTable';
import MatchesTable from './MatchesTable';

const LostFoundTable = ({
  activeTab,
  filteredLostItems = [],
  filteredFoundItems = [],
  filteredPickedItems = [],
  markAsFound,
  markAsPicked,
  searchTerm,
  setSearchTerm,
  onViewDetails,
  showMatches,
  fetchPotentialMatches,
  setShowMatches,
  potentialMatches,
  loadingMatches = false
}) => {
  if (showMatches) {
    return (
      <MatchesTable
        potentialMatches={potentialMatches}
        loadingMatches={loadingMatches}
        markAsFound={markAsFound}
        onViewDetails={onViewDetails}
      />
    );
  }

  if (activeTab === 'lost') {
    return (
      <LostItemsTable
        items={filteredLostItems}
        onViewDetails={onViewDetails}
      />
    );
  }

  if (activeTab === 'found') {
    return (
      <FoundItemsTable
        items={filteredFoundItems}
        onViewDetails={onViewDetails}
        markAsPicked={markAsPicked}
      />
    );
  }

  if (activeTab === 'picked') {
    return (
      <PickedItemsTable
        items={filteredPickedItems}
        onViewDetails={onViewDetails}
      />
    );
  }

  return (
    <div className="no-data-message">
      <div className="sad-emoji">😞</div>
      <h3>No items found</h3>
      <p>Please select a tab to view items.</p>
    </div>
  );
};

export default LostFoundTable;