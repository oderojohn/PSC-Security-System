import React from 'react';
import { FiEye, FiCheck } from 'react-icons/fi';

const ItemsTable = ({ items, columns, onViewDetails, isLost, isFound, onMarkAsPicked }) => {
  const safeText = (val, fallback = 'N/A') => {
    if (val === null || val === undefined) return fallback;
    return typeof val === 'string' ? val : 
           typeof val === 'object' ? JSON.stringify(val) : 
           String(val);
  };

  const sortItemsByDate = (items) => {
    if (!items || !Array.isArray(items)) return [];
    return [...items].sort((a, b) => {
      const dateA = a.date_reported ? new Date(a.date_reported).getTime() : 0;
      const dateB = b.date_reported ? new Date(b.date_reported).getTime() : 0;
      return dateB - dateA;
    });
  };

  const sortedItems = sortItemsByDate(items);

  return (
    <div className="table-container" style={{ maxHeight: '500px', overflowY: 'auto' }}>
      <table className="items-table">
        <colgroup>
          {columns.map((col, index) => (
            <col key={index} style={{ width: col.width }} />
          ))}
        </colgroup>
        <thead>
          <tr>
            {columns.map((col, index) => (
              <th key={index}>{col.header}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {sortedItems.length > 0 ? (
            sortedItems.map(item => (
              <TableRow
                key={item.id}
                item={item}
                isLost={isLost}
                isFound={isFound}
                onViewDetails={onViewDetails}
                onMarkAsPicked={onMarkAsPicked}
                safeText={safeText}
              />
            ))
          ) : (
            <tr>
              <td colSpan={columns.length} className="no-data-message">
                No items found
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

const TableRow = ({ item, isLost, isFound, onViewDetails, onMarkAsPicked, safeText }) => {
  const rowProps = !isLost ? {
    onClick: () => onViewDetails(item),
    className: 'clickable-row'
  } : {};

  return (
    <tr {...rowProps}>
      <td>{item.type === 'card' ? '💳 Card' : '🧳 Item'}</td>
      <td>
        {item.type === 'card'
          ? `${safeText(item.card_type)} (${safeText(item.card_last_four)})`
          : `${safeText(item.item_name, 'Unnamed')} - ${safeText(item.description, 'No description')}`}
      </td>
      <td>{safeText(item.owner_name, 'Unknown')}</td>
      <td>{isLost ? safeText(item.place_lost) : safeText(item.place_found)}</td>
      <td>{isLost ? safeText(item.reporter_member_id) : safeText(item.finder_name)}</td>
      <td>{isLost ? safeText(item.reporter_phone) : safeText(item.finder_phone)}</td>
      <td>{item.date_reported ? new Date(item.date_reported).toLocaleString() : 'N/A'}</td>
      <td>
        <span className={`status-badge ${item.status || 'pending'}`}>
          {item.status || 'pending'}
        </span>
      </td>
      <td>
        {isFound && item.status === 'found' && (
          <button
            className="btn btn-sm btn-success"
            onClick={(e) => {
              e.stopPropagation();
              onMarkAsPicked(item.id);
            }}
          >
            <FiCheck /> Picked
          </button>
        )}
        {/* {!isLost && !isFound && (
          <button
            className="btn btn-sm btn-outline-primary"
            onClick={(e) => {
              e.stopPropagation();
              onViewDetails(item);
            }}
          >
            <FiEye /> Details
          </button>
        )} */}
      </td>
    </tr>
  );
};

export default ItemsTable;