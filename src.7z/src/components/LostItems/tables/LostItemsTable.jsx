import React from 'react';
import ItemsTable from './ItemsTable';

const LostItemsTable = ({ items, onViewDetails }) => {
 const columns = [
    { header: 'Type', width: '9%' },
    { header: 'Details', width: '24%' },
    { header: 'Owner', width: '13%' },
    { header: 'Place Found', width: '13%' },
    { header: 'Found By', width: '13%' },
    { header: 'Phone', width: '8%' },
    { header: 'Date & Time', width: '15%' },
    { header: 'Status', width: '10%' }
  ];

  return (
    <ItemsTable
      items={items}
      columns={columns}
      onViewDetails={onViewDetails}
      isLost={true}
    />
  );
};

export default LostItemsTable;