import React, { useState } from 'react';
import ItemsTable from './ItemsTable';
import ConfirmationModal from '../ConfirmationModal';

const FoundItemsTable = ({ items, onViewDetails, markAsPicked }) => {
  const [showPickedConfirmModal, setShowPickedConfirmModal] = useState(false);
  const [selectedItemId, setSelectedItemId] = useState(null);

  const columns = [
    { header: 'Type', width: '10%' },
    { header: 'Details', width: '22%' },
    { header: 'Owner', width: '12%' },
    { header: 'Place Found', width: '12%' },
    { header: 'Found By', width: '12%' },
    { header: 'Phone', width: '10%' },
    { header: 'Date & Time', width: '12%' },
    { header: 'Status', width: '10%' },
  ];

  const handleMarkAsPicked = (itemId) => {
    setSelectedItemId(itemId);
    setShowPickedConfirmModal(true);
  };

  const confirmMarkAsPicked = async () => {
    setShowPickedConfirmModal(false);
    await markAsPicked(selectedItemId);
  };

  return (
    <>
      <ItemsTable
        items={items}
        columns={columns}
        onViewDetails={onViewDetails}
        onMarkAsPicked={handleMarkAsPicked}
      />
      
      <ConfirmationModal
        show={showPickedConfirmModal}
        onClose={() => setShowPickedConfirmModal(false)}
        onConfirm={confirmMarkAsPicked}
        title="Confirm Mark as Picked"
        message="Are you sure you want to mark this item as picked? This action cannot be undone."
      />
    </>
  );
};

export default FoundItemsTable;