import React, { useRef, useState, useEffect } from 'react';
import { FiCamera, FiUpload, FiX, FiAlertCircle, FiLink } from 'react-icons/fi';

export const ReportFoundForm = ({ onClose, onSubmit }) => {
  const fileInputRef = useRef(null);
  const videoRef = useRef(null);
  const [formData, setFormData] = useState({
    type: 'card',
    card_last_four: '',
    item_name: '',
    description: '',
    place_found: '',
    finder_name: '',
    finder_phone: '',
    owner_name: '',
    photo: null
  });
  const [photoPreview, setPhotoPreview] = useState(null);
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [cameraActive, setCameraActive] = useState(false);

  useEffect(() => {
    return () => {
      if (photoPreview) {
        URL.revokeObjectURL(photoPreview);
      }
      stopCamera();
    };
  }, [photoPreview]);

  const validateForm = () => {
    const newErrors = {};
    if (formData.type === 'card' && !/^[A-Z]\d{4}[A-Z]?$/.test(formData.card_last_four)) {
      newErrors.card_last_four = 'Please enter a valid card number (e.g., K1234 or K1234A)';
    }
    if (formData.type === 'item' && !formData.item_name.trim()) {
      newErrors.item_name = 'Item name is required';
    }
    if (!formData.place_found.trim()) {
      newErrors.place_found = 'Location is required';
    }
    if (!formData.finder_name.trim()) {
      newErrors.finder_name = 'Your name is required';
    }
    if (!/^\d{10,15}$/.test(formData.finder_phone)) {
      newErrors.finder_phone = 'Valid phone number is required (10-15 digits)';
    }
    if (formData.type === 'item' && !formData.photo) {
      newErrors.photo = 'Please add a photo of the item';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setPhotoPreview(URL.createObjectURL(file));
      setFormData({ ...formData, photo: file });
    }
  };

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      setCameraActive(true);
    } catch (err) {
      console.error("Error accessing camera:", err);
      setErrors({ ...errors, photo: 'Could not access camera' });
    }
  };

  const stopCamera = () => {
    if (videoRef.current?.srcObject) {
      videoRef.current.srcObject.getTracks().forEach(track => track.stop());
    }
    setCameraActive(false);
  };

  const takePhoto = () => {
    if (videoRef.current) {
      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth;
      canvas.height = videoRef.current.videoHeight;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);

      canvas.toBlob((blob) => {
        if (blob) {
          const file = new File([blob], `photo_${Date.now()}.jpg`, { type: 'image/jpeg' });
          setPhotoPreview(URL.createObjectURL(blob));
          setFormData({ ...formData, photo: file });
        }
      }, 'image/jpeg');
      stopCamera();
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;
    
    setIsSubmitting(true);
    
    try {
      const formPayload = new FormData();
      
      // Append all form fields
      Object.entries(formData).forEach(([key, value]) => {
        if (value !== null && value !== undefined) {
          formPayload.append(key, value);
        }
      });
      
      // Debug: log FormData contents
      for (let [key, value] of formPayload.entries()) {
        console.log(key, value instanceof File ? `File: ${value.name}` : value);
      }

      onSubmit(formPayload);
      onClose();
    } catch (error) {
      console.error('Error submitting form:', error);
      setErrors({ 
        ...errors, 
        form: error.response?.data?.message || 'Failed to submit form. Please try again.' 
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="lf-modal-overlay">
      <div className="lf-modal-container">
        <div className="lf-modal-header">
          <h3><FiLink /> Report Found Item</h3>
          <button className="lf-modal-close-btn" onClick={onClose} disabled={isSubmitting}>
            <FiX />
          </button>
        </div>

        <div className="lf-modal-body">
          {errors.form && (
            <div className="lf-error-message">
              <FiAlertCircle className="lf-error-icon" />
              {errors.form}
            </div>
          )}

          <form onSubmit={handleSubmit} noValidate>
            <div className="lf-form-group">
              <label>Item Type</label>
              <select 
                className={`lf-form-control ${errors.type ? 'is-invalid' : ''}`} 
                value={formData.type} 
                onChange={(e) => {
                  setFormData({ 
                    ...formData, 
                    type: e.target.value, 
                    photo: null,
                    card_last_four: '',
                    item_name: ''
                  });
                  setPhotoPreview(null);
                }}
              >
                <option value="card">Card</option>
                <option value="item">Item</option>
              </select>
            </div>

            {formData.type === 'card' ? (
              <div className="lf-form-group">
                <label>Card Number</label>
                <input
                  className={`lf-form-control ${errors.card_last_four ? 'is-invalid' : ''}`}
                  type="text"
                  placeholder="e.g., K1234 or K1234A"
                  maxLength="6"
                  value={formData.card_last_four}
                  onChange={(e) => {
                    const input = e.target.value.toUpperCase();
                    const valid = /^[A-Z]\d{0,4}[A-Z]?$/.test(input);
                    if (valid || input === '') {
                      setFormData({ ...formData, card_last_four: input });
                    }
                  }}
                  required
                />
                {errors.card_last_four && (
                  <div className="lf-error-feedback">
                    <FiAlertCircle className="lf-error-icon" />
                    {errors.card_last_four}
                  </div>
                )}
              </div>
            ) : (
              <>
                <div className="lf-form-group">
                  <label>Item Name</label>
                  <input
                    className={`lf-form-control ${errors.item_name ? 'is-invalid' : ''}`}
                    type="text"
                    placeholder="e.g., AirPods, Wallet"
                    value={formData.item_name}
                    onChange={(e) => setFormData({ ...formData, item_name: e.target.value })}
                    required
                  />
                  {errors.item_name && (
                    <div className="lf-error-feedback">
                      <FiAlertCircle className="lf-error-icon" />
                      {errors.item_name}
                    </div>
                  )}
                </div>

                <div className="lf-form-group">
                  <label>Photo</label>
                  {photoPreview ? (
                    <>
                      <img 
                        src={photoPreview} 
                        alt="Preview" 
                        className="lf-photo-preview"
                      />
                      <button 
                        type="button" 
                        className="lf-btn lf-btn-secondary"
                        onClick={() => {
                          setFormData({ ...formData, photo: null });
                          setPhotoPreview(null);
                        }}
                      >
                        <FiX /> Retake
                      </button>
                    </>
                  ) : cameraActive ? (
                    <>
                      <video 
                        ref={videoRef} 
                        autoPlay 
                        playsInline 
                        className="lf-camera-preview"
                      />
                      <div className="lf-camera-controls">
                        <button 
                          type="button" 
                          className="lf-btn lf-btn-secondary"
                          onClick={stopCamera}
                        >
                          <FiX /> Cancel
                        </button>
                        <button 
                          type="button" 
                          className="lf-btn lf-btn-primary"
                          onClick={takePhoto}
                        >
                          <FiCamera /> Take Photo
                        </button>
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="lf-photo-placeholder">
                        <FiCamera size={32} />
                      </div>
                      <div className="lf-photo-options">
                        <button 
                          type="button" 
                          className="lf-btn lf-btn-secondary"
                          onClick={() => fileInputRef.current.click()}
                        >
                          <FiUpload /> Upload
                        </button>
                        <button 
                          type="button" 
                          className="lf-btn lf-btn-primary"
                          onClick={startCamera}
                        >
                          <FiCamera /> Camera
                        </button>
                      </div>
                      <input 
                        type="file" 
                        ref={fileInputRef}
                        onChange={handleFileChange}
                        accept="image/*"
                        capture="environment"
                        className="lf-file-input"
                      />
                    </>
                  )}
                  {errors.photo && (
                    <div className="lf-error-feedback">
                      <FiAlertCircle className="lf-error-icon" />
                      {errors.photo}
                    </div>
                  )}
                </div>

                <div className="lf-form-group">
                  <label>Description</label>
                  <textarea
                    className={`lf-form-control ${errors.description ? 'is-invalid' : ''}`}
                    placeholder="Describe the item (color, brand, distinguishing features)"
                    rows="3"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    required
                  />
                  {errors.description && (
                    <div className="lf-error-feedback">
                      <FiAlertCircle className="lf-error-icon" />
                      {errors.description}
                    </div>
                  )}
                </div>
              </>
            )}

            <div className="lf-form-group">
              <label>Owner Name (if known)</label>
              <input 
                className="lf-form-control" 
                type="text" 
                placeholder="Owner's name" 
                value={formData.owner_name} 
                onChange={(e) => setFormData({ ...formData, owner_name: e.target.value })} 
              />
            </div>

            <div className="lf-form-group">
              <label>Place Found</label>
              <input
                className={`lf-form-control ${errors.place_found ? 'is-invalid' : ''}`}
                type="text"
                placeholder="Where was it found?"
                value={formData.place_found}
                onChange={(e) => setFormData({ ...formData, place_found: e.target.value })}
                required
              />
              {errors.place_found && (
                <div className="lf-error-feedback">
                  <FiAlertCircle className="lf-error-icon" />
                  {errors.place_found}
                </div>
              )}
            </div>

            <div className="lf-form-group">
              <label>Your Name</label>
              <input
                className={`lf-form-control ${errors.finder_name ? 'is-invalid' : ''}`}
                type="text"
                placeholder="Your full name"
                value={formData.finder_name}
                onChange={(e) => setFormData({ ...formData, finder_name: e.target.value })}
                required
              />
              {errors.finder_name && (
                <div className="lf-error-feedback">
                  <FiAlertCircle className="lf-error-icon" />
                  {errors.finder_name}
                </div>
              )}
            </div>

            <div className="lf-form-group">
              <label>Your Phone Number</label>
              <input
                className={`lf-form-control ${errors.finder_phone ? 'is-invalid' : ''}`}
                type="tel"
                placeholder="10-15 digits"
                value={formData.finder_phone}
                onChange={(e) => {
                  const value = e.target.value.replace(/\D/g, '');
                  setFormData({ ...formData, finder_phone: value });
                }}
                required
              />
              {errors.finder_phone && (
                <div className="lf-error-feedback">
                  <FiAlertCircle className="lf-error-icon" />
                  {errors.finder_phone}
                </div>
              )}
            </div>

            <div className="lf-modal-footer">
              <button 
                type="button" 
                className="lf-btn lf-btn-secondary" 
                onClick={onClose} 
                disabled={isSubmitting}
              >
                Cancel
              </button>
              <button 
                type="submit" 
                className="lf-btn lf-btn-primary" 
                disabled={isSubmitting}
              >
                {isSubmitting ? 'Submitting...' : 'Submit Report'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};