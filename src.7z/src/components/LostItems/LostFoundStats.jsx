import React, { useState } from 'react';
import { FiPlus, FiList } from 'react-icons/fi';
import { ReportFoundForm } from './forms/ReportFoundForm';
import { ReportLostForm } from './forms/ReportLostForm';

const LostFoundStats = ({
  activeTab,
  setActiveTab,
  lostItems,
  foundItems,
  pendingItems,
  showMatches,
  setShowMatches,
  fetchPotentialMatches,
  onLostSubmit,
  onFoundSubmit
}) => {
  const [showLostModal, setShowLostModal] = useState(false);
  const [showFoundModal, setShowFoundModal] = useState(false);

  const handleTabClick = (tab) => {
    setActiveTab(tab);
    setShowMatches(false);
  };

  const handleMatchClick = () => {
    setShowMatches(!showMatches);
    if (!showMatches) {
      fetchPotentialMatches();
    }
  };

 const handleLostSubmit = (newItem) => {
  console.log("New lost item submitted:", newItem);
  // update state or refetch list
};

  const handleFoundSubmit = (formData) => {
    onFoundSubmit(formData);
    setShowFoundModal(false);
  };

  return (
    <>
      <div className="dashboard-toolbar">
        <div className="stats-summary">
          {/* <div
            className={`stat ${activeTab === 'lost' && !showMatches ? 'active' : ''}`}
            onClick={() => handleTabClick('lost')}
          >
            <span>Lost</span>
            <strong>{lostItems}</strong>
          </div> */}
          {/* <div
            className={`stat ${activeTab === 'found' && !showMatches ? 'active' : ''}`}
            onClick={() => handleTabClick('found')}
          >
            <span>Found</span>
            <strong>{foundItems}</strong>
          </div>
          <div
            className={`stat ${activeTab === 'picked' ? 'active' : ''}`}
            onClick={() => handleTabClick('picked')}
          >
            <span>Picked</span>
          </div>
          <div
            className={`stat ${showMatches ? 'active' : ''}`}
            onClick={handleMatchClick}
          >
            <span>Matches</span>
          </div> */}
        </div>

        <div className="right-controls">
          <div className="tab-controls">
            <button
              className={`tab-button ${activeTab === 'lost' && !showMatches ? 'active' : ''}`}
              onClick={handleMatchClick}
            >
              <FiList size={16} /> Matches
            </button>
            <button
              className={`tab-button ${activeTab === 'lost' && !showMatches ? 'active' : ''}`}
              onClick={() => handleTabClick('lost')}
            >
              <FiList size={16} /> Lost Cards 
            </button>
            <button
              className={`tab-button ${activeTab === 'lost' && !showMatches ? 'active' : ''}`}
              onClick={() => handleTabClick('lost')}
            >
              <FiList size={16} /> Lost Items
            </button>
            <button
              className={`tab-button ${activeTab === 'found' && !showMatches ? 'active' : ''}`}
              onClick={() => handleTabClick('found')}
            >
              <FiList size={16} /> Found Cards
            </button>
            <button
              className={`tab-button ${activeTab === 'found' && !showMatches ? 'active' : ''}`}
              onClick={() => handleTabClick('found')}
            >
              <FiList size={16} /> Found Items
            </button>
            <button
              className={`tab-button ${activeTab === 'picked' ? 'active' : ''}`}
              onClick={() => handleTabClick('picked')}
            >
              <FiList size={16} /> Picked
            </button>
          </div>
          <div className="action-buttons">
            <button
              className={`add-button ${activeTab === 'lost' ? 'primary' : 'secondary'}`}
              onClick={() => setShowLostModal(true)}
            >
              <FiPlus size={16} /> Report Lost
            </button>
            <button
              className={`add-button ${activeTab === 'found' ? 'primary' : 'secondary'}`}
              onClick={() => setShowFoundModal(true)}
            >
              <FiPlus size={16} /> Report Found
            </button>
          </div>
        </div>
      </div>

      {showLostModal && (
        <ReportLostForm 
          onClose={() => setShowLostModal(false)}
          onSubmit={handleLostSubmit}
        />
      )}

      {showFoundModal && (
        <ReportFoundForm 
          onClose={() => setShowFoundModal(false)}
          onSubmit={handleFoundSubmit}
        />
      )}
    </>
  );
};

export default LostFoundStats;