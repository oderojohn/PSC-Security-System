import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

import Sidebar from './components/Sidebar';
import Logo from './components/Logo';
import './App.css';

// Import page components
import Dashboard from './components/pages/Dashboard';
import RegisterGuest from './components/pages/Dashboard';
import LostItemsDashboard from './components/LostItemsDashboard'; 
import Events from './components/pages/Dashboard';
import Announcements from './components/pages/Dashboard';
import SecurityControl from './components/pages/Dashboard';
import Reports from './components/pages/Dashboard';
import ReportIssue from './components/pages/Dashboard';
import TopNavbar from './components/TopNavbar'
import PackageDashboard  from './components/Dropped Packages/PackageDashboard'


const App = () => {
  return (
    <Router>
      <div className="app">
        <Logo />
        <TopNavbar/>
        <Sidebar />
        <div className="main-content">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/register" element={<RegisterGuest />} />
            <Route path="/lost-items" element={<LostItemsDashboard />} />
            <Route path="/dropped-packages" element={<PackageDashboard  />} />
            <Route path="/events" element={<Events />} />
            <Route path="/announcements" element={<Announcements />} />
            <Route path="/security" element={<SecurityControl />} />
            <Route path="/reports" element={<Reports />} />
            <Route path="/report-issue" element={<ReportIssue />} />
          </Routes>
        </div>
      </div>
    </Router>
  );
};

export default App;
