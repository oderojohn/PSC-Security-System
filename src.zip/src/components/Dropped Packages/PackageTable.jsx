import React from 'react';
import { FiCheck, FiEye } from 'react-icons/fi';

const PackageTable = ({
  activeTab,
  filteredDroppedPackages,
  filteredPickedPackages,
  markAsPicked,
  searchTerm,
  setSearchTerm,
  onViewDetails
}) => {
  const renderNoDataMessage = () => (
    <div className="no-data-message">
      <div className="sad-emoji">📦</div>
      <h3>No packages found</h3>
      <p>We couldn't find any {activeTab === 'drop' ? 'dropped' : 'picked'} packages matching your search.</p>
      {searchTerm && (
        <button className="clear-search" onClick={() => setSearchTerm('')}>
          Clear search
        </button>
      )}
    </div>
  );

  const renderRow = (pkg, isDropped = false) => {
    const rowProps = !isDropped ? { onClick: () => onViewDetails(pkg), className: 'clickable-row' } : {};
    return (
      <tr key={pkg.id} {...rowProps}>
        <td>{pkg.type === 'document' ? '📄 Document' : '📦 Package'}</td>
        <td>{pkg.description}</td>
        <td>{pkg.recipientName}</td>
        <td>{pkg.recipientPhone}</td>
        <td>{isDropped ? pkg.droppedBy : pkg.pickedBy}</td>
        <td>{pkg.date}</td>
        <td><span className={`status-badge ${pkg.status}`}>{pkg.status}</span></td>
        <td>
          {isDropped && pkg.status === 'pending' ? (
            <button
              className="found-button"
              onClick={(e) => {
                e.stopPropagation();
                markAsPicked(pkg.id);
              }}
            >
              <FiCheck /> Mark Picked
            </button>
          ) : (
            <button
              className="view-button"
              onClick={(e) => {
                e.stopPropagation();
                onViewDetails(pkg);
              }}
            >
              <FiEye /> Details
            </button>
          )}
        </td>
      </tr>
    );
  };

  if (activeTab === 'drop') {
    if (!filteredDroppedPackages.length) return renderNoDataMessage();
    return (
      <table className="items-table">
        <thead>
          <tr>
            <th>Type</th>
            <th>Description</th>
            <th>Recipient Name</th>
            <th>Recipient Phone</th>
            <th>Dropped By</th>
            <th>Date & Time</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredDroppedPackages.map(pkg => renderRow(pkg, true))}
        </tbody>
      </table>
    );
  } else {
    if (!filteredPickedPackages.length) return renderNoDataMessage();
    return (
      <table className="items-table">
        <thead>
          <tr>
            <th>Type</th>
            <th>Description</th>
            <th>Recipient Name</th>
            <th>Recipient Phone</th>
            <th>Picked By</th>
            <th>Date & Time</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredPickedPackages.map(pkg => renderRow(pkg))}
        </tbody>
      </table>
    );
  }
};

export default PackageTable;